package bankaccountapp;

public abstract class Account implements IBaseRate {
	
//	Steps for this class :- 
	
	// List common properties for saving and checking account:- 
	private String name;
	private String sSN;
	protected String accountNumber;
	private double balance;
	protected double rate;
	private static int index = 10000;
	
	
	
	
	// Constructor to set base properties and initialise the account:-
	public Account(String name,String sSN, double initDeposit) {
		
		this.sSN = sSN;
		this.name = name;
		balance = initDeposit;
//		System.out.println("NAME: "+name + " SSN: "+ sSN+" balance "+ balance);
//		System.out.print("NEW ACCOUNT: ");
		
		// Set account number:- 
		index++;
		this.accountNumber = setAccountNumber();
//		System.out.println("ACCOUNT NUMBER :"+accountNumber);
		rate = getBaseRate();
//		System.out.println(getBaseRate());
		setRate();
		
		
	}
	
	public abstract void setRate();
	
	
	
	
	
	private String setAccountNumber() {
		
		String lastTwoOfSSN = sSN.substring(sSN.length()-2, sSN.length());
		int uniqeId  = index;
		int randomNumber = (int) (Math.random()* Math.pow(10, 3));
		
		return lastTwoOfSSN+ uniqeId+ randomNumber;
		}
	
	public void compound() {
		
		double accuredInterest = balance *(rate/100);
		balance = balance + accuredInterest;
		System.out.println("Accured Interest: "+accuredInterest);
		printBalance();
	}
	
	
	// List common methods:- 
	public void showInfo() {
		System.out.println(
				"NAME: "+ name+
				"\nACCOUNT NUMBER: "+ accountNumber+
				"\nBALANCE: "+ balance+
				"\nRATE: "+ rate+"%"
				);
	}
	
	
	
	public void deposit(double amount) {
		balance = balance + amount;
		System.out.println("depositing $"+amount);
		printBalance();
	}
	
	public void withdraw(double amount) {
			balance = balance - amount;
			System.out.println("Withdrawing $"+amount);
			printBalance();
	}
	
	public void transfer(String toWhere, double amount) {
		balance = balance - amount;
		System.out.println("Transferring $"+ amount+ " to"+ toWhere);
		printBalance();
		
	}
	
	public void printBalance() {
		System.out.println("Your Balance is now: $"+ balance);
		
	}
	
	public void show() {
		
	}
		
		
		
		
		
	
	
	
	
	
	
	

}
