package bankaccountapp;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class BankAccountApp {

	public static void main(String[] args) throws IOException {
		
		/*
		Checking ch1 = new Checking("Mohit Jangid","124242132",1500);
		Savings sv1 = new Savings("Virat Kohli","73728462",1800);
		sv1.compound();
		sv1.showInfo();
		System.out.println("********************************");
		sv1.showInfo();
		
		sv1.deposit(1222);
		sv1.withdraw(1200);
		sv1.transfer("Brokerage", 100);
		*/
		
		List<Account> accounts = new LinkedList<Account>();
		
		
		
		
		String file = System.getProperty("user.dir")+"/src/utilities/NewBankAccounts.csv";
		
		// Read a csv file then create new accounts based on that data:-
		
		List<String[]> newAccountHolder = utilities.CSV.read(file);
		for (String[] accountHolder : newAccountHolder) {
			System.out.println("NEW ACCOUNTS: ");
			
			String name = accountHolder[0];
			String sSN = accountHolder[1];
			String accountType = accountHolder[2];
			double initDeposit = Double.parseDouble(accountHolder[3]);
			
			System.out.println(name + " "+ sSN+" "+ accountType+" "+ initDeposit);
			
			if (accountType.equals("Savings")) {
//				System.out.println("OPEN A SAVING ACCOUNT");
				accounts.add(new Savings(name,sSN, initDeposit));
			}
			else if (accountType.equals("Checking")) {
//				System.out.println("OPEN A CHECKING ACCOUNT");
				accounts.add(new Checking(name,sSN, initDeposit));
			}
			else {
				System.out.println("ERROR READING ACCOUNT TYPE");
				
			}
		}
		
//		accounts.get(5).showInfo();
		
		
		for (Account acc : accounts) {
			acc.showInfo();
			System.out.println(("-----------------------------"));
		}
		
		
		

	}

}
