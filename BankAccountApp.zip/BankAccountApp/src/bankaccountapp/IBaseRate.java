package bankaccountapp;

public interface IBaseRate {
	
	// write a method which return the base rate
	
	default double getBaseRate() {
		
		return 2.5;
	}
	

}
