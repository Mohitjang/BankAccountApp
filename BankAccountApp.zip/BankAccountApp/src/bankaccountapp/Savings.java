package bankaccountapp;

public class Savings extends Account{
	
		// List properties specific to saving account
	private int safetyDepositBoxID;
	private int safetyDepositKey;

	
	
	
		// CONSTRCTOR TO initialise settign for the saving acc peroperties
	public Savings(String name,String sSN, double initDeposit) {
		super(name,sSN,initDeposit);
		accountNumber = "1"+accountNumber;
		setSafetyDepositBox();
//		System.out.println("ACCOUNT NUMBER :"+accountNumber);
//		System.out.println("NEW SAVINGS ACCOUNT");
//		System.out.println("NAME: "+ name);
	}
		
	@Override
	public void setRate() {
//		System.out.println("Implement Rate for Saving");
		rate = getBaseRate() - .25;
	}
	
	
		// List any maethhod specific to saving account
	
	public void showInfo() {
		System.out.println("ACCOUNT TYPE: Savings ");
		super.showInfo();
		System.out.println("Your savings account features:\nsafetyDepositBoxID: "+ safetyDepositBoxID+"\nsafetyDepositKey: "+safetyDepositKey);
		
	}
	
	private void setSafetyDepositBox() {
		
		safetyDepositBoxID = (int) (Math.random() * Math.pow(10, 3));
		safetyDepositKey = (int) (Math.random() * Math.pow(10, 4));
//		System.out.println(safetyDepositBoxID);
		
	}

}
